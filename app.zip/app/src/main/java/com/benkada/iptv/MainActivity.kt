package com.benkada.iptv

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val server = findViewById<EditText>(R.id.serverInput)
        val username = findViewById<EditText>(R.id.usernameInput)
        val password = findViewById<EditText>(R.id.passwordInput)

        findViewById<Button>(R.id.demoPlayButton).setOnClickListener {
            if (server.text.isBlank() || username.text.isBlank() || password.text.isBlank()) {
                Toast.makeText(this, "Enter your server, username and password", Toast.LENGTH_SHORT).show()
            } else {
                // Credentials are deliberately not stored in this starter.
                Toast.makeText(this, "Login/API connection is the next implementation step", Toast.LENGTH_LONG).show()
            }
        }
    }
}
